package metrics

import "github.com/emicklei/go-restful"

func GetAppMetrics(request *restful.Request, response *restful.Response) {

}
