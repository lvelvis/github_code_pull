/*

 Copyright 2019 The KubeSphere Authors.

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

     http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.

*/
package job

import "time"

const (
	Running    = "running"
	Failed     = "failed"
	Unfinished = "unfinished"
	Completed  = "completed"
	Pause      = "pause"
)

type JobRevisions map[int]JobRevision

type JobRevision struct {
	Status         string    `json:"status"`
	Reasons        []string  `json:"reasons,omitempty"`
	Messages       []string  `json:"messages,omitempty"`
	Succeed        int32     `json:"succeed,omitempty"`
	DesirePodNum   int32     `json:"desire,omitempty"`
	Failed         int32     `json:"failed,omitempty"`
	Uid            string    `json:"uid"`
	StartTime      time.Time `json:"start-time,omitempty"`
	CompletionTime time.Time `json:"completion-time,omitempty"`
}
