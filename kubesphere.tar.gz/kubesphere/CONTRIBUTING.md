# Guide

This [document](https://github.com/kubesphere/community) walks you through how to get started contributing KubeSphere.
