# Powered by KubeSphere

This page documents a list of institutions that are using KubeSphere Container Platform for research, testing and production,
or providing commercial products including KubeSphere.

You can open a Pull Request to submit your institution name and homepage if you are using KubeSphere. Thus we can better understand the user's scenarios and further improve project.

- [本来生活](https://www.benlai.com/)
- [新浪](https://sina.cn/)
- 方正株式（武汉）科技开发有限公司
- 武汉麦尔沃克信息技术
- [InAccel - Scale-out FPGA-Accelerated Applications](https://inaccel.com)
